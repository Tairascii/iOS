//
//  AppCell.swift
//  project
//
//  Created by Tair Sairanbekov on 21.05.2021.
//

import UIKit

class AppCell: UITableViewCell {

    @IBOutlet weak var typeL: UILabel!
    @IBOutlet weak var timeL: UILabel!
    @IBOutlet weak var nameL: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
