//
//  PostCell.swift
//  project
//
//  Created by Tair Sairanbekov on 09.05.2021.
//

import UIKit

class PostCell: UITableViewCell {

    @IBOutlet weak var postL: UILabel!
    @IBOutlet weak var nameL: UILabel!
    @IBOutlet weak var typeL: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func appe(){
        typeL.layer.cornerRadius = 4
    }
}
