//
//  CartCell.swift
//  project
//
//  Created by Tair Sairanbekov on 07.05.2021.
//

import UIKit

class CartCell: UITableViewCell {

    @IBOutlet weak var nameL: UILabel!
    @IBOutlet weak var priceL: UILabel!
    @IBOutlet weak var imageO: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
