//
//  CatCell.swift
//  project
//
//  Created by Tair Sairanbekov on 18.05.2021.
//

import UIKit

class CatCell: UITableViewCell {

    @IBOutlet weak var catView: UIView!
    @IBOutlet weak var nameL: UILabel!
    @IBOutlet weak var imageo: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func app(){
        imageo.layer.cornerRadius = 20
        imageo.layer.opacity = 0.8
        catView.layer.cornerRadius = 20
    }

}
