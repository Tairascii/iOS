//
//  MedicineCell.swift
//  project
//
//  Created by Tair Sairanbekov on 06.05.2021.
//

import UIKit

class MedicineCell: UITableViewCell {

    @IBOutlet weak var nameL: UILabel!
    @IBOutlet weak var priceL: UILabel!
    @IBOutlet weak var imageO: UIImageView!
    @IBOutlet weak var addB: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func but(){
        imageO.layer.cornerRadius = 32
        addB.layer.cornerRadius = 9
        addB.backgroundColor = addB.backgroundColor?.withAlphaComponent(0.3)
    }

}
