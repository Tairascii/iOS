//
//  Categories.swift
//  project
//
//  Created by Tair Sairanbekov on 18.05.2021.
//
import UIKit
import Foundation
class Cat{
    var name: String?
    var image: UIImage?
    init(_ name: String, _ image: UIImage){
        self.name = name
        self.image = image
    }
}

