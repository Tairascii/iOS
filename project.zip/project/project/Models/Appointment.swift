//
//  Appointment.swift
//  project
//
//  Created by Tair Sairanbekov on 21.05.2021.
//

import Foundation
import FirebaseDatabase
struct Appointment {
    
    var id: String?
    var email: String?
    var name: String?
    var time: String?
    var type: String?
    var custID: String?
    var dict: [String: String]{
        return [
            "id": id!,
            "email": email!,
            "name": name!,
            "time": time!,
            "type": type!,
            "customerID": custID!
        ]
    }
    
    init(_ id: String, _ email: String, _ name: String, _ time: String, _ type: String, custID: String){
        self.id = id
        self.email = name
        self.name = name
        self.time = time
        self.type = type
        self.custID = custID
    }
    
    init(snapshot: DataSnapshot){
        if let value = snapshot.value as? [String: String]{
            id = value["id"]
            email = value["email"]
            name = value["name"]
            time = value["time"]
            type = value["type"]
            custID = value["customerID"]
        }
        
    }
}
