//
//  Doctor.swift
//  project
//
//  Created by Tair Sairanbekov on 10.05.2021.
//

import Foundation
import Firebase
struct Doctor {
    var id: String?
    var name: String?
    var email: String?
    var image: String?
    var desc: String?
    var userID: String?
    var dict: [String: String]{
        return [
            "id": id!,
            "name": name!,
            "email": email!,
            "image": image!,
            "desc": desc!,
            "userID": userID!
        ]
    }
    
    init(_ id: String, _ name: String, _ email: String, _ image: String, _ desc: String, _ userID: String){
        self.id = id
        self.name = name
        self.email = email
        self.image = image
        self.desc = desc
        self.userID = userID
    }
    
    init(snapshot: DataSnapshot){
        if let value = snapshot.value as? [String: Any]{
            id = value["id"] as? String
            name = value["name"] as? String
            email = value["email"] as? String
            image = value["image"] as? String
            desc = value["desc"] as? String
            userID = value["userID"] as? String
        }
        
    }
}
