//
//  Comment.swift
//  project
//
//  Created by Tair Sairanbekov on 28.05.2021.
//

import Foundation
import FirebaseDatabase

struct Comment {
    var name: String?
    var comment: String?
    var dict: [String: String]{
        return [
            "name": name!,
            "comment": comment!
        ]
    }
    
    init(_ name: String, _ comment:String){
        self.name = name
        self.comment = comment
    }
    
    init(snapshot: DataSnapshot){
        if let value = snapshot.value as? [String: String]{
            name = value["name"]
            comment = value["comment"]
        }
        
    }
}
