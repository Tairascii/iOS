//
//  Medicine.swift
//  project
//
//  Created by Tair Sairanbekov on 06.05.2021.
//

import Foundation
import FirebaseDatabase

struct Medicine {
    var id: String?
    var name: String?
    var price: String?
    var desc: String?
    var quantity: String?
    var image: String?
    var cat: String?
    var dict: [String: String]{
        return [
            "id": id!,
            "name": name!,
            "price": price!,
            "desc": desc!,
            "quantity": quantity!,
            "image": image!,
            "cat": cat!
        ]
    }
    
    init(_ id: String, _ name: String, _ price: String, _ desc: String, _ quantity: String, _ image: String, _ cat:String){
        self.id = id
        self.name = name
        self.price = price
        self.desc = desc
        self.quantity = quantity
        self.image = image
        self.cat = cat
    }
    
    init(snapshot: DataSnapshot){
        if let value = snapshot.value as? [String: String]{
            id = value["id"]
            name = value["name"]
            price = value["price"]
            desc = value["desc"]
            quantity = value["quantity"]
            image = value["image"]
            cat = value["cat"]
        }
        
    }
}
