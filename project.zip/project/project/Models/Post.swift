//
//  Post.swift
//  project
//
//  Created by Tair Sairanbekov on 09.05.2021.
//

import Foundation
import FirebaseDatabase
struct Post {
    var id: String?
    var email: String?
    var name: String?
    var message: String?
    var type: String?
    var docID: String?
    var dict: [String: String]{
        return [
            "id": id!,
            "email": email!,
            "name": name!,
            "message": message!,
            "type": type!,
            "doctorID": docID!
        ]
    }
    
    init(_ id: String, _ email: String, _ name: String, _ message: String, _ type: String, docID: String){
        self.id = id
        self.email = email
        self.name = name
        self.message = message
        self.type = type
        self.docID = docID
    }
    
    init(snapshot: DataSnapshot){
        if let value = snapshot.value as? [String: String]{
            id = value["id"]
            email = value["email"]
            name = value["name"]
            message = value["message"]
            type = value["type"]
            docID = value["doctorID"]
        }
        
    }
}
