//
//  RegView.swift
//  project
//
//  Created by Tair Sairanbekov on 23.04.2021.
//

import UIKit
import Firebase
import FirebaseAuth
class RegView: UIViewController {
    @IBOutlet weak var emailF: UITextField!
    @IBOutlet weak var regBO: UIButton!
    @IBOutlet weak var passF: UITextField!
    @IBOutlet weak var userNameF: UITextField!
    @IBOutlet weak var navBar: UINavigationBar!
    @IBOutlet weak var nameSurnameF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        regBO.layer.cornerRadius = 5
        localization()
        // Do any additional setup after loading the view.
    }
    
    func localization(){
        navBar.topItem?.title = navBar.topItem?.title?.localized()
        emailF.placeholder = emailF.placeholder?.localized()
        passF.placeholder = passF.placeholder?.localized()
        userNameF.placeholder = userNameF.placeholder?.localized()
        nameSurnameF.placeholder = nameSurnameF.placeholder?.localized()
        regBO.setTitle("Register".localized(), for: .normal)
    }
    
    @IBAction func regB(_ sender: UIButton) {
        let nameSurname = nameSurnameF.text
        let userName = userNameF.text
        let email = emailF.text
        let password = passF.text
        if nameSurname != "" && userName != "" && email != "" && password != ""{
            Auth.auth().createUser(withEmail: email!, password: password!) { [weak self] (result, error) in
                Auth.auth().currentUser?.sendEmailVerification(completion: nil)
                if error == nil{
                    let userData = [
                        "email": email!,
                        "name": nameSurname ?? "Name",
                        "userName": userName ?? "User name",
                        "address": "",
                        "card": ""
                    ] as [String : Any]
                    Database.database().reference().child("users").child(result!.user.uid).setValue(userData)
                    self?.showMess(title: "Success", message: "Please verify your email")
                }
                else{
                    self?.showMess(title: "Error", message: "Something went wrong")
                }
            }
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func showMess(title: String, message: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { (UIAlertAction) in
            if title != "Error"{
                self.dismiss(animated: true, completion: nil)
            }
        })
        alert.addAction(ok)
        self.present(alert, animated: true, completion: nil)
    }
}
