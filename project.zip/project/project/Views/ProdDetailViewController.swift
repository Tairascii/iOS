//
//  ProdDetailViewController.swift
//  project
//
//  Created by Tair Sairanbekov on 09.05.2021.
//

import UIKit
import CoreData
class ProdDetailViewController: UIViewController {
    @IBOutlet weak var imageO: UIImageView!
    @IBOutlet weak var nameL: UILabel!
    @IBOutlet weak var descL: UILabel!
    @IBOutlet weak var addBO: UIButton!
    var imageLink: String?
    var name: String?
    var desc: String?
    var price: String?
    var quant: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        addBO.layer.cornerRadius = 10
        guard let url = URL(string: imageLink!) else {
           return
        }
        let getData = URLSession.shared.dataTask(with: url, completionHandler: { data, _, error in
            guard let data = data, error == nil else{
                return
            }
            DispatchQueue.main.sync {
                let image = UIImage(data: data)
                self.imageO.image = image
            }
        })
        getData.resume()
        nameL.text = name
        descL.numberOfLines = 0
        descL.lineBreakMode = .byWordWrapping
        descL.text = desc
        addBO.setTitle("Add to cart for \(price!)", for: .normal)
        // Do any additional setup after loading the view.
    }
    @IBAction func addB(_ sender: UIButton) {
        save(name: name!, price: price!, img: imageLink!)
    }
    
    func save(name: String, price: String, img: String) {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            let context = appDelegate.persistentContainer.viewContext
            if let entity = NSEntityDescription.entity(forEntityName: "Med", in: context) {
                let med = NSManagedObject(entity: entity, insertInto: context)
                med.setValue(name, forKey: "name")
                med.setValue(price, forKey: "price")
                med.setValue(img, forKey: "img")
                do {
                    try context.save()
//                    let cartTab = (self.tabBarController?.viewControllers?[3])! as! CartViewController
//                    cartTab.added.append(med as! Med)
                }
                catch {}
            }
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
