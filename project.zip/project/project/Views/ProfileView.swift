//
//  ProfileView.swift
//  project
//
//  Created by Tair Sairanbekov on 23.04.2021.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseStorage
import MapKit
import CoreLocation
class ProfileView: UIViewController, CLLocationManagerDelegate {
    var currentuser: User?
    var timeApp = 0
    @IBOutlet weak var editBO: UIButton!
    @IBOutlet weak var imageO: UIImageView!
    @IBOutlet weak var nameL: UILabel!
    @IBOutlet weak var emailL: UILabel!
    @IBOutlet weak var emailText: UILabel!
    @IBOutlet weak var addressText: UILabel!
    @IBOutlet weak var cardL: UILabel!
    @IBOutlet weak var addressL: UILabel!
    @IBOutlet weak var navItem: UINavigationItem!
    @IBOutlet weak var cardF: UITextField!
    @IBOutlet weak var addressF: UITextField!
    @IBOutlet weak var nameF: UITextField!
    @IBOutlet weak var imageB: UIButton!
    @IBOutlet weak var map: MKMapView!
    private let storage = Storage.storage().reference()
    let manager = CLLocationManager()
    @IBOutlet weak var currentLocBO: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
        editBO.layer.cornerRadius = 8
        let porfPic = UIImage(systemName: "camera.circle.fill")
        imageO.image = porfPic?.withTintColor(.systemIndigo, renderingMode: .alwaysOriginal)
        imageO.layer.cornerRadius = 35
        findLoc()
        downloadProfile()
        guard let urlString = UserDefaults.standard.value(forKey: "url") as? String,
        let url = URL(string: urlString) else{
            return
        }
        let task = URLSession.shared.dataTask(with: url, completionHandler: { data, _, error in
            guard let data = data, error == nil else{
                return
            }
            DispatchQueue.main.async {
                let image = UIImage(data: data)
                self.imageO.image = image
            }
        })
        task.resume()
        editBO.setTitle("Edit".localized(), for: .normal)
        localization()
        // Do any additional setup after loading the view.
    }
    
    func localization(){
        cardL.text = "Your card".localized()
        addressL.text = "Your address".localized()
    }
    override func viewDidAppear(_ animated: Bool) {
        timeApp += 1
        if timeApp > 1{
            findLoc()
            check()
        }
    }
    
    func check(){
        if (emailText.text?.count) != nil{
            let cnt = emailText.text?.count
            if cnt != 16{
                let alert = UIAlertController(title: "Attention", message: "Your card is invalid", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .cancel, handler: {
                            (_) in
                }))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    func downloadProfile(){
        currentuser = Auth.auth().currentUser
        let ref = Database.database().reference()
        let userID = currentuser?.uid
        ref.child("users").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
            let value = snapshot.value as? NSDictionary
            let name = value?["name"] as? String ?? ""
            let email = value?["email"] as? String ?? ""
            let userName = value?["userName"] as? String ?? ""
            let address = value?["address"] as? String ?? ""
            let card = value?["card"] as? String ?? ""
            self.emailL.text = email
            self.nameL.text = name
            self.nameF.text = name
            self.navItem.title = userName
            self.addressText.text = address
            self.addressF.text = address
            self.emailText.text = card
            self.cardF.text = card
            }) { (error) in
              print(error.localizedDescription)
          }
        
    }
    
    func findLoc(){
        let searchReq = MKLocalSearch.Request()
        searchReq.naturalLanguageQuery = addressText.text
        let activeSearch = MKLocalSearch(request: searchReq)
        activeSearch.start(completionHandler: { (response, error) in
            if response == nil{
                print("error")
            }
            else{
                self.map.removeAnnotations(self.map.annotations)
                let latitude = response?.boundingRegion.center.latitude
                let longitude = response?.boundingRegion.center.longitude
                let annotation = MKPointAnnotation()
                annotation.title = self.addressText.text
                annotation.coordinate = CLLocationCoordinate2DMake(latitude!, longitude!)
                self.map.addAnnotation(annotation)
                let coordinate:CLLocationCoordinate2D = CLLocationCoordinate2D(latitude: latitude!, longitude: longitude!)
                let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
                let region = MKCoordinateRegion(center: coordinate, span: span)
                self.map.setRegion(region, animated: true)
            }
        })
    }
    
    @IBAction func editB(_ sender: UIButton) {
        nameL.isHidden = !nameL.isHidden
        nameF.isHidden = !nameF.isHidden
        addressF.isHidden = !addressF.isHidden
        cardF.isHidden = !cardF.isHidden
        imageB.isHidden = !imageB.isHidden
        if nameF.text != "" && addressF.text != ""{
            let userData = [
                "email": currentuser?.email,
                "name": nameF.text,
                "userName": navItem.title,
                "address": addressF.text,
                "card": cardF.text,
            ]
            let ref = Database.database().reference()
            let userID = Auth.auth().currentUser?.uid
            ref.child("users").child(userID!).setValue(userData)
            viewDidLoad()
        }
    }
    
    @IBAction func signOutB(_ sender: UIButton) {
        do{
            try Auth.auth().signOut()
        }
        catch{
            print("Error")
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    @IBAction func imageBB(_ sender: UIButton) {
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        picker.allowsEditing = true
        present(picker, animated: true)
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.first{
            manager.stopUpdatingLocation()
            render(location)
        }
    }
    
    func render(_ location: CLLocation){
        let coordinate = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let span = MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        let region = MKCoordinateRegion(center: coordinate, span: span)
        map.setRegion(region, animated: true)
        let anotation = MKPointAnnotation()
        anotation.coordinate = coordinate
        map.addAnnotation(anotation)
    }
}

extension ProfileView: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
        picker.dismiss(animated: true, completion: nil)
        guard let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage else{
            return
        }
        guard let imageData = image.pngData() else {
            return
        }
        storage.child("/images/\(String(describing: currentuser?.uid))").putData(imageData, metadata: nil, completion: {_, error in
            guard error == nil else{
                print("Fail")
                return
            }
            self.storage.child("/images/\(String(describing: self.currentuser?.uid))").downloadURL(completion: {url, error in
                guard let url = url, error == nil else{
                    return
                }
                let urlString = url.absoluteString
                DispatchQueue.main.async {
                    self.imageO.image = image
                }
                UserDefaults.standard.setValue(urlString, forKey: "url")
            })
        })
    }

    @available(iOS 2.0, *)
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        picker.dismiss(animated: true, completion: nil)
    }
}

extension String{
    func localized() -> String{
        return NSLocalizedString(self,
                                 tableName: "Localizable",
                                 bundle: .main,
                                 value: self,
                                 comment: self)
    }
}
