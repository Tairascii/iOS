//
//  DoctorProfViewController.swift
//  project
//
//  Created by Tair Sairanbekov on 26.05.2021.
//

import UIKit
import Firebase

class DoctorProfViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var userid = "lWxEOXjA0uZwYqSpxcRaDsubial2"
    
    @IBOutlet weak var navBar: UINavigationBar!
    @IBOutlet weak var nameL: UILabel!
    @IBOutlet weak var descL: UILabel!
    @IBOutlet weak var comL: UILabel!
    @IBOutlet weak var myTable: UITableView!
    
    var coms: [Comment] = []
    var currentuser: User?
    var ref = Database.database().reference()
    override func viewDidLoad() {
        super.viewDidLoad()
        navBar.topItem?.title = "Profile".localized()
        comL.text = "Comments".localized()
        currentuser = Auth.auth().currentUser
        let userID = currentuser?.uid
        if userID != nil{
            userid = userID!
        }
        getProf()
        getComs()
        descL.numberOfLines = 0
        descL.lineBreakMode = .byWordWrapping
        myTable.delegate = self
        myTable.dataSource = self
        
        // Do any additional setup after loading the view.
    }
    func getProf(){
        ref.child("doctors").child(userid).observeSingleEvent(of: .value, with: { (snapshot) in
            let value = snapshot.value as? NSDictionary
            let name = value?["name"] as? String ?? ""
            let desc = value?["desc"] as? String ?? ""
            self.nameL.text = name
            self.descL.text = desc
            }) { (error) in
              print(error.localizedDescription)
          }
    }
    
    func getComs(){
        let parent = ref.child("doctors").child(userid).child("comments")
        parent.observe(.value){ [weak self] (snapshot) in
            self?.coms.removeAll()
            for child in snapshot.children{
                if let snap = child as? DataSnapshot{
                    let post = Comment(snapshot: snap)
                    self?.coms.append(post)
                }
            }
            self?.coms.reverse()
            print(self!.coms)
            self?.myTable.reloadData()
        }
    }

    @IBAction func signOutB(_ sender: UIButton) {
        do{
            try Auth.auth().signOut()
        }
        catch{
            print("Error")
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return coms.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "commentCell", for: indexPath)
        cell.textLabel?.text = coms[indexPath.row].comment
        cell.detailTextLabel?.text = coms[indexPath.row].name
        return cell
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
