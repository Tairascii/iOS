//
//  DoctorsViewController.swift
//  project
//
//  Created by Tair Sairanbekov on 10.05.2021.
//

import UIKit
import Firebase
class DoctorsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var searchB: UISearchBar!
    @IBOutlet weak var myTable: UITableView!
    @IBOutlet weak var navBar: UINavigationBar!
    var docs: [Doctor] = []
    var searchDocs: [Doctor] = []
    var searching = false
    override func viewDidLoad() {
        super.viewDidLoad()
        myTable.dataSource = self
        myTable.delegate = self
        searchB.delegate = self
        getDB()
        navBar.topItem?.title = navBar.topItem?.title?.localized()
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching{
            return searchDocs.count
        }
        return docs.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        myTable.deselectRow(at: indexPath, animated: true)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "doctorCell") as? DoctorCell
        if searching{
            cell?.nameL.text = searchDocs[indexPath.row].name
            cell?.emailL.text = searchDocs[indexPath.row].email
            guard let url = URL(string: searchDocs[indexPath.row].image!) else {
               return cell!
            }
            let getData = URLSession.shared.dataTask(with: url, completionHandler: { data, _, error in
                guard let data = data, error == nil else{
                    return
                }
                DispatchQueue.main.sync {
                    let image = UIImage(data: data)
                    cell?.imageO.image = image
                }
            })
            getData.resume()
        }
        else{
            cell?.nameL.text = docs[indexPath.row].name
            cell?.emailL.text = docs[indexPath.row].email
            guard let url = URL(string: docs[indexPath.row].image!) else {
               return cell!
            }
            let getData = URLSession.shared.dataTask(with: url, completionHandler: { data, _, error in
                guard let data = data, error == nil else{
                    return
                }
                DispatchQueue.main.sync {
                    let image = UIImage(data: data)
                    cell?.imageO.image = image
                }
            })
            getData.resume()
        }
        cell?.imageO.layer.cornerRadius = 32
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 75
    }
    
    func getDB(){
        let ref = Database.database().reference()
        let parent = ref.child("doctors")
        parent.observe(.value){ [weak self] (snapshot) in
            self?.docs.removeAll()
            for child in snapshot.children{
                if let snap = child as? DataSnapshot{
                    let doc = Doctor(snapshot: snap)
                    self?.docs.append(doc)
                }
            }
            
            self?.myTable.reloadData()
        }
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDDetail"{
            if let navcon = segue.destination as? DDetailViewController{
                navcon.imageLink = docs[(myTable.indexPathForSelectedRow?.row)!].image
                navcon.name = docs[(myTable.indexPathForSelectedRow?.row)!].name
                navcon.desc = docs[(myTable.indexPathForSelectedRow?.row)!].desc
                navcon.userID = docs[(myTable.indexPathForSelectedRow?.row)!].userID
            }
        }
    }

}

extension DoctorsViewController: UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchDocs = docs.filter({$0.name!.lowercased().prefix(searchText.count) ==  searchText.lowercased()})
        searching = true
        myTable.reloadData()
    }
}
