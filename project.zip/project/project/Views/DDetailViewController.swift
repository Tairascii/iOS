//
//  DDetailViewController.swift
//  project
//
//  Created by Tair Sairanbekov on 13.05.2021.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase
class DDetailViewController: UIViewController {
    var currentuser: User?
    var ref = Database.database().reference()
    var imageLink: String?
    var name: String?
    var desc: String?
    var userID: String?
    var cnt = 0
    @IBOutlet weak var imageO: UIImageView!
    @IBOutlet weak var nameL: UILabel!
    @IBOutlet weak var descL: UILabel!
    @IBOutlet weak var timeP: UIDatePicker!
    @IBOutlet weak var appBO: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        getData()
        timeP.minimumDate = Date()
        appBO.layer.cornerRadius = 10
        appBO.setTitle("Make an appointment".localized(), for: .normal)
        // Do any additional setup after loading the view.
    }
    
    func getData(){
        self.cnt = Int.random(in: 0...100000)
        guard let url = URL(string: imageLink!) else {
           return
        }
        let getData = URLSession.shared.dataTask(with: url, completionHandler: { data, _, error in
            guard let data = data, error == nil else{
                return
            }
            DispatchQueue.main.sync {
                let image = UIImage(data: data)
                self.imageO.image = image
            }
        })
        getData.resume()
        nameL.text = name
        descL.numberOfLines = 0
        descL.lineBreakMode = .byWordWrapping
        descL.text = desc
    }
    

    @IBAction func appB(_ sender: UIButton) {
        currentuser = Auth.auth().currentUser
        let userID = currentuser?.uid
        ref.child("users").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
            let value = snapshot.value as? NSDictionary
            let name = value?["name"] as? String ?? ""
            let email = value?["email"] as? String ?? ""
            let formatter = DateFormatter()
            formatter.dateFormat = "dd.MM.yy HH:mm"
            let time = formatter.string(from: self.timeP.date)
            let appointment = [
                "id": String(self.cnt),
                "customerID": userID!,
                "email": email,
                "name": name,
                "time": time,
                "type": "unchecked"
            ] as [String : Any]
            self.ref.child("doctors").child(self.userID!).child("appointments").child(String(self.cnt)).setValue(appointment)
            }) { (error) in
              print(error.localizedDescription)
          }
        self.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
