//
//  AppointmentsView.swift
//  project
//
//  Created by Tair Sairanbekov on 21.05.2021.
//

import UIKit
import Firebase
import FirebaseDatabase
import FirebaseAuth
class AppointmentsView: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var currentuser: User?
    var userid = "lWxEOXjA0uZwYqSpxcRaDsubial2"
    var ref = Database.database().reference()
    var apps: [Appointment] = []
    @IBOutlet weak var myTable: UITableView!
    
    @IBOutlet weak var navBar: UINavigationBar!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return apps.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "appCell") as? AppCell
        cell?.timeL.text = apps[indexPath.row].time
        cell?.nameL.text = apps[indexPath.row].name
        if apps[indexPath.row].type == "accepted"{
            cell?.typeL.backgroundColor = .systemGreen
        }
        else if apps[indexPath.row].type == "unchecked"{
            cell?.typeL.backgroundColor = .systemIndigo
        }
        else{
            cell?.typeL.backgroundColor = .systemRed
        }
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 75
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        myTable.dataSource = self
        myTable.delegate = self
        let userID = currentuser?.uid
        if userID != nil{
            userid = userID!
        }
        getAppointments()
        navBar.topItem?.title = navBar.topItem?.title?.localized()
        currentuser = Auth.auth().currentUser
        
        // Do any additional setup after loading the view.
    }
    
    func getAppointments(){
        let parent = ref.child("doctors").child(userid).child("appointments")
        parent.observe(.value){ [weak self] (snapshot) in
            self?.apps.removeAll()
            for child in snapshot.children{
                if let snap = child as? DataSnapshot{
                    let app = Appointment(snapshot: snap)
                    self?.apps.append(app)
                }
            }
            self?.myTable.reloadData()
        }
    }
    
    func reject(rowIndexPathAt indexPath: IndexPath) -> UIContextualAction{
        let action = UIContextualAction(style: .destructive, title: "Reject".localized(), handler: { _,_,_ in
            var ind = self.apps[indexPath.row]
            ind.type = "rejected"
            let childUpdates = ["/doctors/\(self.userid)/appointments/"+(self.apps[indexPath.row].id)!: nil] as [String : Any?]
            self.ref.updateChildValues(childUpdates as [AnyHashable : Any])
            self.ref.child("doctors").child(self.userid).observeSingleEvent(of: .value, with: { (snapshot) in
                let value = snapshot.value as? NSDictionary
                let name = value?["name"] as? String ?? ""
                let email = value?["email"] as? String ?? ""
                let cnt = Int.random(in: 0...100000)
                let message = [
                    "id": String(cnt),
                    "doctorID": self.userid,
                    "email": email,
                    "name": name,
                    "message": "Doctor will not be able to accept you at \(ind.time ?? "here")",
                    "type": "rejected"
                ] as [String : Any]
                self.ref.child("users")
                    .child(ind.custID!)
                    .child("conv").child(String(cnt)).setValue(message)
                }) { (error) in
                  print(error.localizedDescription)
              }
        })
        return action
    }
    
    func accept(rowIndexPathAt indexPath: IndexPath) -> UIContextualAction{
        let action = UIContextualAction(style: .normal, title: "Accept".localized(), handler: { _,_,_ in
            var ind = self.apps[indexPath.row]
            ind.type = "accepted"
            let app = Appointment(ind.id!, ind.name!, ind.email!, ind.time!, ind.type!, custID: ind.custID!)
            let childUpdates = ["/doctors/\(self.userid)/appointments/"+(ind.id)!: app.dict]
            self.ref.updateChildValues(childUpdates as [AnyHashable : Any])
            self.ref.child("doctors").child(self.userid).observeSingleEvent(of: .value, with: { (snapshot) in
                let value = snapshot.value as? NSDictionary
                let name = value?["name"] as? String ?? ""
                let email = value?["email"] as? String ?? ""
                let cnt = Int.random(in: 0...100000)
                let message = [
                    "id": String(cnt),
                    "doctorID": self.userid,
                    "email": email,
                    "name": name,
                    "message": "Doctor is waiting for you at \(ind.time ?? "here")",
                    "type": "unchecked"
                ] as [String : Any]
                self.ref.child("users")
                    .child(self.apps[indexPath.row].custID!)
                    .child("conv").child(String(cnt)).setValue(message)
                }) { (error) in
                  print(error.localizedDescription)
              }
        })
        return action
    }
    
    func del(rowIndexPathAt indexPath: IndexPath) -> UIContextualAction{
        let action = UIContextualAction(style: .destructive, title: "Delete".localized(), handler: { _,_,_ in
            var ind = self.apps[indexPath.row]
            ind.type = "rejected"
            let childUpdates = ["/doctors/\(self.userid)/appointments/"+(self.apps[indexPath.row].id)!: nil] as [String : Any?]
            self.ref.updateChildValues(childUpdates as [AnyHashable : Any])
        })
        return action
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let accept = self.accept(rowIndexPathAt: indexPath)
        let reject = self.reject(rowIndexPathAt: indexPath)
        let delete = self.del(rowIndexPathAt: indexPath)
        var swipe = UISwipeActionsConfiguration(actions: [delete])
        if apps[indexPath.row].type == "unchecked"{
            swipe = UISwipeActionsConfiguration(actions: [accept, reject])
        }
        return swipe
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
