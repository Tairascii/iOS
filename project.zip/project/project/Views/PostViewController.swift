//
//  PostViewController.swift
//  project
//
//  Created by Tair Sairanbekov on 09.05.2021.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase
import BLTNBoard
class PostViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var ref = Database.database().reference()
    var ind = IndexPath(index: 1)
    var id = 0
    lazy var boardmanager: BLTNItemManager = {
        let item = BLTNPageItem(title: "Confirmation".localized())
        item.actionButtonTitle = "Confirm".localized()
        item.alternativeButtonTitle = "No".localized()
        item.descriptionText = "Were you seen by the doctor at the time you appointed?".localized()
        item.actionHandler = { _ in
            self.dismiss(animated: true, completion: nil)
            self.confirmed(type: "confirmed")
        }
        item.alternativeHandler = { _ in
            self.dismiss(animated: true, completion: nil)
            self.confirmed(type: "rejected")
        }
        item.appearance.actionButtonColor = .systemIndigo
        item.appearance.alternativeButtonTitleColor = .gray
        return BLTNItemManager(rootItem: item)
    }()
    var posts: [Post] = []
    var currentuser: User?
    @IBOutlet weak var myTable: UITableView!
    @IBOutlet weak var navBar: UINavigationBar!
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        posts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "postCell") as? PostCell
        cell?.nameL.text = posts[indexPath.row].name
        cell?.postL.text = posts[indexPath.row].message
        if posts[indexPath.row].type == "unchecked"{
            cell?.typeL.backgroundColor = .systemIndigo
        }
        else if posts[indexPath.row].type == "confirmed"{
            cell?.typeL.backgroundColor = .systemGreen
        }
        else{
            cell?.typeL.backgroundColor = .systemRed
        }
        return cell!
    }
    
    internal func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
            return 75
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myTable.delegate = self
        myTable.dataSource = self
        navBar.topItem?.title = "Notifications".localized()
        loadPost()
        // Do any additional setup after loading the view.
    }
    
    func loadPost(){
        currentuser = Auth.auth().currentUser
        let ref = Database.database().reference()
        let userID = currentuser?.uid
        let parent = ref.child("users").child(userID!).child("conv")
        parent.observe(.value){ [weak self] (snapshot) in
            self?.posts.removeAll()
            for child in snapshot.children{
                if let snap = child as? DataSnapshot{
                    let post = Post(snapshot: snap)
                    self?.posts.append(post)
                }
            }
            self?.posts.reverse()
            self?.myTable.reloadData()
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        self.ind = indexPath
        if posts[ind.row].type == "unchecked"{
            boardmanager.showBulletin(above: self)
        }
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            currentuser = Auth.auth().currentUser
            let userID = currentuser?.uid
            let childUpdates = ["/users/\(userID!)/conv/"+(self.posts[indexPath.row].id)!: nil] as [String : Any?]
            self.ref.updateChildValues(childUpdates as [AnyHashable : Any])
            loadPost()
            viewDidAppear(false)
            myTable.reloadData()
        }
    }
    
    func confirmed(type: String){
        currentuser = Auth.auth().currentUser
        let userID = currentuser?.uid
        var name = ""
        var title = ""
        ref.child("doctors").child("\(self.posts[ind.row].docID!)").child("comments").observe(DataEventType.value, with: { (snapshot) in
            self.id = Int(snapshot.childrenCount)
          })
        ref.child("users").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
            let value = snapshot.value as? NSDictionary
            name = value?["name"] as? String ?? ""
            }) { (error) in
              print(error.localizedDescription)
          }
        var ind = self.posts[ind.row]
        ind.type = type
        let app = Post(ind.id!, ind.email!, ind.name!, ind.message!, ind.type!, docID: ind.docID!)
        let childUpdates = ["/users/\(userID!)/conv/"+(ind.id)!: app.dict]
        self.ref.updateChildValues(childUpdates as [AnyHashable : Any])
        if type == "confirmed"{
            title = "How did everything go?".localized()
        }
        else{
            title = "What happened?".localized()
        }
        let alert = UIAlertController(title: "Leave a comment".localized(), message: title, preferredStyle: .alert)
        alert.addTextField{ (textField) in
            textField.placeholder = "Comment".localized()
        }
        alert.addAction(UIAlertAction(title: "Cancel".localized(), style: .cancel, handler: {
            (_) in
        }))
        alert.addAction(UIAlertAction(title: "Comment".localized(), style: .default, handler: {
            [weak alert] (_) in
            let textField = alert?.textFields![0]
            let comment = Comment(name, textField?.text ?? "Thank You!")
            
            self.ref.child("doctors").child("\(ind.docID!)").child("comments").child(String(self.id)).setValue(comment.dict)
            
           
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
}
