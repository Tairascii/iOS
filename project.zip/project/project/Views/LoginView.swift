//
//  LoginView.swift
//  project
//
//  Created by Tair Sairanbekov on 23.04.2021.
//

import UIKit
import Firebase
import FirebaseAuth
class LoginView: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource  {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        pickerData.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return pickerData[row]
    }
    
    var pickerData:[String]=[String]()
    @IBOutlet weak var emailF: UITextField!
    @IBOutlet weak var passF: UITextField!
    @IBOutlet weak var logBO: UIButton!
    @IBOutlet weak var fbBO: UIButton!
    @IBOutlet weak var orO: UILabel!
    @IBOutlet weak var imageO: UIImageView!
    @IBOutlet weak var pickerB: UIPickerView!
    
    var currentUser: User?
    override func viewDidLoad() {
        super.viewDidLoad()
        pickerB.delegate = self
        pickerB.dataSource = self
        pickerData = ["Customer".localized(), "Doctor".localized()]
        style()
        localization()
        // Do any additional setup after loading the view.
    }
    
    func style(){
        logBO.layer.cornerRadius = 5
        emailF.layer.position.x -= 400
        passF.layer.position.x += 400
        logBO.alpha = 0
        fbBO.alpha = 0
        orO.alpha = 0
        fbBO.layer.position.y = fbBO.layer.position.y - 40
        imageO.image = UIImage.init(named: "logo")
        imageO.alpha = 0
        UIView.animate(withDuration: 1){
            self.emailF.center = CGPoint(x: self.emailF.layer.position.x+400, y: self.emailF.layer.position.y)
            self.passF.center = CGPoint(x: self.passF.layer.position.x-400, y: self.passF.layer.position.y)
        }
        UIView.animate(withDuration: 1, delay: 1) {
            self.fbBO.layer.position.y = self.fbBO.layer.position.y + 40
            self.logBO.alpha = 1
            self.fbBO.alpha = 1
            self.orO.alpha = 1
            self.imageO.alpha = 1
        }
    }
    
    func localization(){
        emailF.placeholder = emailF.placeholder?.localized()
        passF.placeholder = passF.placeholder?.localized()
        orO.text = orO.text?.localized()
        logBO.setTitle("Login".localized(), for: .normal)
        fbBO.setTitle("Register".localized(), for: .normal)
    }
    
    @IBAction func logB(_ sender: UIButton) {
        goToMain()
        let email = emailF.text
        let password = passF.text
        if email != "" && password != ""{
            Auth.auth().signIn(withEmail: email!, password: password!){ [weak self]
                (result, error) in
                if error == nil{
                    if Auth.auth().currentUser!.isEmailVerified{
                        self?.goToMain()
                    }
                    else{
                        self?.showMess(title: "Warning", message: "Your email is not verified")
                    }
                }
                else{

                }
            }
        }
        emailF.text = ""
        passF.text = ""
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func showMess(title: String, message: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { (UIAlertAction) in
            if title != "Error"{
                self.dismiss(animated: true, completion: nil)
            }
        })
        alert.addAction(ok)
        self.present(alert, animated: true, completion: nil)
    }
    
    func goToMain(){
        let ind = pickerB.selectedRow(inComponent: 0).description
        if Int(ind) == 0{
            let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
            if let mainPage = storyboard.instantiateViewController(identifier: "MainView") as? UITabBarController{
                mainPage.modalPresentationStyle = .fullScreen
                present(mainPage, animated: true, completion: nil)
            }
        }
        else{
            let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
            if let mainPage = storyboard.instantiateViewController(identifier: "DoctorView") as? UITabBarController{
                mainPage.modalPresentationStyle = .fullScreen
                present(mainPage, animated: true, completion: nil)
            }
        }
    }

}
