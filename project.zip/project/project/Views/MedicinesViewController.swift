//
//  MedicinesViewController.swift
//  project
//
//  Created by Tair Sairanbekov on 06.05.2021.
//

import UIKit
import Firebase
import CoreData
class MedicinesViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var cats: [Cat] = [Cat.init("Medicines".localized(), UIImage.init(named: "med")!),Cat.init("Vitamins".localized(), UIImage.init(named: "vita")!),Cat.init("Care and Beauty".localized(), UIImage.init(named: "care")!),Cat.init("Baby".localized(), UIImage.init(named: "baby")!), Cat.init("Show all".localized(), UIImage.init(named: "show")!)]
    var meds: [Medicine] = []
    var searchMeds: [Medicine] = []
    var searching = false
    var ref = Database.database().reference()
    @IBOutlet weak var myTable: UITableView!
    @IBOutlet weak var serchB: UISearchBar!
    @IBOutlet weak var catTable: UITableView!
    @IBOutlet weak var refBO: UIBarButtonItem!
    @IBOutlet weak var navBar: UINavigationBar!
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView != catTable{
            if searching{
                return searchMeds.count
            }
            return meds.count
        }
        return cats.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == catTable{
            catTable.deselectRow(at: indexPath, animated: false)
            catTable.isHidden = true
            if indexPath.row != 4{
                meds = meds.filter({Int($0.cat!)! ==  indexPath.row+1})
                myTable.reloadData()
            }
        }
        else{
            myTable.deselectRow(at: indexPath, animated: true)
        }
        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if tableView == self.catTable{
            let cell = tableView.dequeueReusableCell(withIdentifier: "catCell") as? CatCell
            cell?.nameL.text = cats[indexPath.row].name
            cell?.imageo.image = cats[indexPath.row].image
            cell?.app()
            if cell != nil{
                return cell!
            }
        }
        else{
            let cell = tableView.dequeueReusableCell(withIdentifier: "medCell") as? MedicineCell
            if searching{
                cell?.nameL.text = searchMeds[indexPath.row].name
                cell?.priceL.text = searchMeds[indexPath.row].price
                guard let url = URL(string: searchMeds[indexPath.row].image!) else {
                   return cell!
                }
                let getData = URLSession.shared.dataTask(with: url, completionHandler: { data, _, error in
                    guard let data = data, error == nil else{
                        return
                    }
                    DispatchQueue.main.sync {
                        let image = UIImage(data: data)
                        cell?.imageO.image = image
                    }
                })
                getData.resume()
            }
            else{
                cell?.nameL.text = meds[indexPath.row].name
                cell?.priceL.text = meds[indexPath.row].price
                guard let url = URL(string: meds[indexPath.row].image!) else {
                   return cell!
                }
                let getData = URLSession.shared.dataTask(with: url, completionHandler: { data, _, error in
                    guard let data = data, error == nil else{
                        return
                    }
                    DispatchQueue.main.sync {
                        let image = UIImage(data: data)
                        cell?.imageO.image = image
                    }
                })
                getData.resume()
            }
            cell?.but()
            return cell!
        }
        return UITableViewCell()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if tableView == catTable{
            return 150
        }
            return 75
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        if tableView == catTable{
            cell.alpha = 0
            UIView.animate(withDuration: 0.5, delay: Double(indexPath.row)*0.5, animations: {
                cell.alpha = 1
                })
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        myTable.delegate = self
        myTable.dataSource = self
        catTable.delegate = self
        catTable.dataSource = self
        catTable.separatorStyle = .none
        serchB.delegate = self
        navBar.topItem?.title = navBar.topItem?.title?.localized()
        getDB()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func refB(_ sender: UIBarButtonItem) {
        catTable.isHidden = false
        getDB()
    }
    func getDB(){
        let ref = Database.database().reference()
        let parent = ref.child("medicines")
        parent.observe(.value){ [weak self] (snapshot) in
            self?.meds.removeAll()
            for child in snapshot.children{
                if let snap = child as? DataSnapshot{
                    let med = Medicine(snapshot: snap)
                    self?.meds.append(med)
                }
            }
            self?.myTable.reloadData()
        }
    }
    
    func updateDB(){
        catTable.isHidden = false
        let cartTab = (self.tabBarController?.viewControllers?[3])! as! CartViewController
        let added = cartTab.added
        for med in added{
            for medicine in meds{
                if med.name == medicine.name{
                    if Int(medicine.quantity!)!>0{
                        let quant = Int(medicine.quantity!)!-1
                        let newMed = Medicine(medicine.id!, medicine.name!, medicine.price!, medicine.desc!, String(quant), medicine.image!, medicine.cat!)
                        let childUpdates = ["/medicines/"+(medicine.id)!: newMed.dict]
                        ref.updateChildValues(childUpdates as [AnyHashable : Any])
                    }
                    
                }
            }
        }
    }
    
    @IBAction func addBB(_ sender: UIButton) {
        guard let cell = sender.superview?.superview as? MedicineCell else {
            return
        }
        let indexPath = myTable.indexPath(for: cell)
        let name = meds[indexPath?.row ?? 0].name
        let price = meds[indexPath?.row ?? 0].price
        let img = meds[indexPath?.row ?? 0].image
        save(name: name!, price: price!, img: img!)
    }
    
    func save(name: String, price: String, img: String) {
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            let context = appDelegate.persistentContainer.viewContext
            if let entity = NSEntityDescription.entity(forEntityName: "Med", in: context) {
                let med = NSManagedObject(entity: entity, insertInto: context)
                med.setValue(name, forKey: "name")
                med.setValue(price, forKey: "price")
                med.setValue(img, forKey: "img")
                do {
                    try context.save()
                    let cartTab = (self.tabBarController?.viewControllers?[3])! as! CartViewController
                    cartTab.added.append(med as! Med)
                }
                catch {}
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail"{
            if let navcon = segue.destination as? ProdDetailViewController{
                navcon.imageLink = meds[(myTable.indexPathForSelectedRow?.row)!].image
                navcon.name = meds[(myTable.indexPathForSelectedRow?.row)!].name
                navcon.desc = meds[(myTable.indexPathForSelectedRow?.row)!].desc
                navcon.price = meds[(myTable.indexPathForSelectedRow?.row)!].price
                navcon.quant = meds[(myTable.indexPathForSelectedRow?.row)!].quantity
            }
        }
    }

}

extension MedicinesViewController: UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchMeds = meds.filter({$0.name!.lowercased().prefix(searchText.count) ==  searchText.lowercased()})
        searching = true
        myTable.reloadData()
    }
}
