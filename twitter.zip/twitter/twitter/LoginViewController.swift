//
//  LoginViewController.swift
//  twitter
//
//  Created by Tair Sairanbekov on 14.04.2021.
//

import UIKit
import Firebase
import FirebaseAuth
class LoginViewController: UIViewController {
    @IBOutlet weak var logoI: UIImageView!
    
    @IBOutlet weak var emailF: UITextField!
    @IBOutlet weak var passF: UITextField!
    @IBOutlet weak var loginO: UIButton!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    var currentUser: User?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        currentUser = Auth.auth().currentUser
        logoI.image = UIImage.init(named: "twitter")
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        currentUser = Auth.auth().currentUser
        if currentUser != nil && currentUser!.isEmailVerified{
            goToMain()
        }
    }

    @IBAction func logB(_ sender: UIButton) {
        let email = emailF.text
        let password = passF.text
        indicator.startAnimating()
        if email != "" && password != ""{
            Auth.auth().signIn(withEmail: email!, password: password!){ [weak self]
                (result, error) in
                self?.indicator.stopAnimating()
                if error == nil{
                    if Auth.auth().currentUser!.isEmailVerified{
                        self?.goToMain()
                    }
                    else{
                        self?.showMess(title: "Warning", message: "Your email is not verified")
                    }
                }
                else{
                    
                }
            }
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func showMess(title: String, message: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { (UIAlertAction) in
            if title != "Error"{
                self.dismiss(animated: true, completion: nil)
            }
        })
        alert.addAction(ok)
        self.present(alert, animated: true, completion: nil)
    }
    
    func goToMain(){
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        if let mainPage = storyboard.instantiateViewController(identifier: "TwitterViewController") as? TwitterViewController{
            mainPage.modalPresentationStyle = .fullScreen
            present(mainPage, animated: true, completion: nil)
        }
    }
}
