//
//  TwitterViewController.swift
//  twitter
//
//  Created by Tair Sairanbekov on 14.04.2021.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase
import FirebaseStorage
class TwitterViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    var currentuser: User?
    @IBOutlet weak var searchB: UISearchBar!
    @IBOutlet weak var myTable: UITableView!
    @IBOutlet weak var nameSurnameL: UILabel!
    @IBOutlet weak var birthDayL: UILabel!
    @IBOutlet weak var image: UIImageView!
    @IBOutlet weak var navItem: UINavigationItem!
    @IBOutlet weak var newNameF: UITextField!
    @IBOutlet weak var newDateF: UITextField!
    @IBOutlet weak var imageb: UIButton!
    var tweets: [Tweet] = []
    var searchTweets: [Tweet] = []
    var searching = false
    private let storage = Storage.storage().reference()
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if searching{
            return searchTweets.count
        }
        return tweets.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "tweetCell", for: indexPath) as? TweetCell
        if searching{
            cell?.nick.text = searchTweets[indexPath.row].nick
            cell?.date.text = searchTweets[indexPath.row].date
            cell?.hashtag.text = searchTweets[indexPath.row].hashtag
            cell?.tweet.text = searchTweets[indexPath.row].tweet
        }
        else{
            cell?.nick.text = tweets[indexPath.row].nick
            cell?.date.text = tweets[indexPath.row].date
            cell?.hashtag.text = tweets[indexPath.row].hashtag
            cell?.tweet.text = tweets[indexPath.row].tweet
        }
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        image.layer.cornerRadius = 35
        myTable.delegate = self
        myTable.dataSource = self
        searchB.delegate = self
        if !newNameF.isHidden{
            navItem.title = "Edit Profile"
        }
        else{
            navItem.title = "Twitter"
        }
        guard let urlString = UserDefaults.standard.value(forKey: "url") as? String,
        let url = URL(string: urlString) else{
            return
        }
        let task = URLSession.shared.dataTask(with: url, completionHandler: { data, _, error in
            guard let data = data, error == nil else{
                return
            }
            DispatchQueue.main.async {
                let image = UIImage(data: data)
                self.image.image = image
            }
        })
        task.resume()
        currentuser = Auth.auth().currentUser
        let ref = Database.database().reference()
        let parent = ref.child("tweets")
        parent.observe(.value){ [weak self] (snapshot) in
            self?.tweets.removeAll()
            for child in snapshot.children{
                if let snap = child as? DataSnapshot{
                    let tweet = Tweet(snapshot: snap)
                    self?.tweets.append(tweet)
                }
            }
            self?.tweets.reverse()
            self?.myTable.reloadData()
        }
        let userID = Auth.auth().currentUser?.uid
        ref.child("users").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
            let value = snapshot.value as? NSDictionary
            let name = value?["name"] as? String ?? ""
            let date = value?["date"] as? String ?? ""
            self.nameSurnameL.text = name
            self.birthDayL.text = date
            self.newNameF.text = name
            self.newDateF.text = date
            }) { (error) in
              print(error.localizedDescription)
          }
    }
    
    func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let ref = Database.database().reference()
        let editButton = UITableViewRowAction(style: .default, title: "Edit"){
            (rowaction, indexpath) in
            let alert = UIAlertController(title: "New Tweet", message: "Enter text", preferredStyle: .alert)
            alert.addTextField{ (textField) in
                textField.text = self.tweets[indexpath.row].tweet
            }
            alert.addTextField{ (textField) in
                textField.text = self.tweets[indexpath.row].hashtag
            }
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: {
                (_) in
               
            }))
            alert.addAction(UIAlertAction(title: "Edit", style: .default, handler: {
                [weak alert] (_) in
                let textField = alert?.textFields![0]
                let textField2 = alert?.textFields![1]
                let date = Date()
                let formatter = DateFormatter()
                formatter.dateFormat = "dd.MM.yyyy HH:mm"
                let resultDate = formatter.string(from: date)
                let tweet = Tweet(self.tweets[indexpath.row].id!, textField!.text!, resultDate, (self.currentuser?.email)!, textField2!.text!)
                let childUpdates = ["/tweets/"+(self.tweets[indexPath.row].id)!: tweet.dict]
                ref.updateChildValues(childUpdates as [AnyHashable : Any])
               
            }))
            
            self.present(alert, animated: true, completion: nil)
            
        }
        editButton.backgroundColor = .systemTeal
        let deleteButton = UITableViewRowAction(style: .default, title: "Delete"){ [self]
            (rowaction, indexpath) in
            let childUpdates = ["/tweets/"+(tweets[indexPath.row].id)!: nil] as [String : Any?]
            ref.updateChildValues(childUpdates as [AnyHashable : Any])
        }
        deleteButton.backgroundColor = .systemPink
        return [deleteButton, editButton]
    }
    @IBAction func signOutB(_ sender: UIBarButtonItem) {
        do{
            try Auth.auth().signOut()
        }
        catch{
            print("Error")
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func newTweetB(_ sender: UIButton) {
        let alert = UIAlertController(title: "New Tweet", message: "Enter text", preferredStyle: .alert)
        alert.addTextField{ (textField) in
            textField.placeholder = "Your Tweet"
        }
        alert.addTextField{ (textField) in
            textField.placeholder = "Your Hashtag"
        }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: {
            (_) in
           
        }))
        alert.addAction(UIAlertAction(title: "Tweet", style: .default, handler: {
            [weak alert] (_) in
            let id = String(self.tweets.count)
            let textField = alert?.textFields![0]
            let textField2 = alert?.textFields![1]
            let date = Date()
            let formatter = DateFormatter()
            formatter.dateFormat = "dd.MM.yyyy HH:mm"
            let resultDate = formatter.string(from: date)
            let tweet = Tweet(id, textField!.text!, resultDate, (self.currentuser?.email)!, textField2!.text!)
            Database.database().reference().child("tweets").child(id).setValue(tweet.dict)
           
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
    @IBAction func editB(_ sender: UIBarButtonItem) {
        imageb.isHidden = !imageb.isHidden
        newNameF.isHidden = !newNameF.isHidden
        newDateF.isHidden = !newDateF.isHidden
        if newNameF.text != "" && newDateF.text != ""{
            let userData = [
                "email": currentuser?.email,
                "name": newNameF.text,
                "date": newDateF.text,
            ]
            let ref = Database.database().reference()
            let userID = Auth.auth().currentUser?.uid
            ref.child("users").child(userID!).setValue(userData)
            viewDidLoad()
        }
        
    }
    
    @IBAction func imageB(_ sender: UIButton) {
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        picker.allowsEditing = true
        present(picker, animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension TwitterViewController: UISearchBarDelegate{
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        searchTweets = tweets.filter({$0.hashtag!.lowercased().prefix(searchText.count) ==  searchText.lowercased()})
        searching = true
        myTable.reloadData()
    }
}
extension TwitterViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
        picker.dismiss(animated: true, completion: nil)
        guard let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage else{
            return
        }
        guard let imageData = image.pngData() else {
            return
        }
        storage.child("/images/file.png").putData(imageData, metadata: nil, completion: {_, error in
            guard error == nil else{
                print("Fail")
                return
            }
            self.storage.child("/images/file.png").downloadURL(completion: {url, error in
                guard let url = url, error == nil else{
                    return
                }
                let urlString = url.absoluteString
                DispatchQueue.main.async {
                    self.image.image = image
                }
                UserDefaults.standard.setValue(urlString, forKey: "url")
            })
        })
    }

    @available(iOS 2.0, *)
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        picker.dismiss(animated: true, completion: nil)
    }
}
