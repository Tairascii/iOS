//
//  RegViewController.swift
//  twitter
//
//  Created by Tair Sairanbekov on 14.04.2021.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseStorage
class RegViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var imageb: UIButton!
    @IBOutlet weak var nameSurF: UITextField!
    @IBOutlet weak var dateF: UITextField!
    @IBOutlet weak var emailF: UITextField!
    @IBOutlet weak var passF: UITextField!
    @IBOutlet weak var regO: UIButton!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    @IBOutlet weak var image: UIImageView!
    private let storage = Storage.storage().reference()
    override func viewDidLoad() {
        super.viewDidLoad()
        imageb.layer.borderWidth = 1
        imageb.layer.borderColor = .init(red: 0, green: 198, blue: 245, alpha: 1)
        imageb.layer.cornerRadius = 45
        image.layer.cornerRadius = 45
        guard let urlString = UserDefaults.standard.value(forKey: "url") as? String,
        let url = URL(string: urlString) else{
            return
        }
        let task = URLSession.shared.dataTask(with: url, completionHandler: { data, _, error in
            guard let data = data, error == nil else{
                return
            }
            DispatchQueue.main.async {
                let image = UIImage(data: data)
                self.image.image = image
            }
        })
        task.resume()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func regB(_ sender: UIButton) {
        let nameSurname = nameSurF.text
        let birthDay = dateF.text
        let email = emailF.text
        let password = passF.text
        if nameSurname != "" && birthDay != "" && email != "" && password != ""{
            indicator.startAnimating()
            Auth.auth().createUser(withEmail: email!, password: password!) { [weak self] (result, error) in
                self?.indicator.stopAnimating()
                Auth.auth().currentUser?.sendEmailVerification(completion: nil)
                guard let urlString = UserDefaults.standard.value(forKey: "url") as? String,
                let url = URL(string: urlString) else{
                    return
                }
                if error == nil{
                    let userData = [
                        "email": email!,
                        "name": nameSurname ?? "Name",
                        "date": birthDay ?? "Birth Date",
                    ] as [String : Any]
                    Database.database().reference().child("users").child(result!.user.uid).setValue(userData)

                    self?.showMess(title: "Success", message: "Please verify your email")
                }
                else{
                    self?.showMess(title: "Error", message: "Something went wrong")
                }
            }
        }
    }
    @IBAction func imageB(_ sender: UIButton) {
        let picker = UIImagePickerController()
        picker.sourceType = .photoLibrary
        picker.delegate = self
        picker.allowsEditing = true
        present(picker, animated: true)
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
        picker.dismiss(animated: true, completion: nil)
        guard let image = info[UIImagePickerController.InfoKey.editedImage] as? UIImage else{
            return
        }
        guard let imageData = image.pngData() else {
            return
        }
        storage.child("/images/file.png").putData(imageData, metadata: nil, completion: {_, error in
            guard error == nil else{
                print("Fail")
                return
            }
            self.storage.child("/images/file.png").downloadURL(completion: {url, error in
                guard let url = url, error == nil else{
                    return
                }
                let urlString = url.absoluteString
                DispatchQueue.main.async {
                    self.image.image = image
                }
                UserDefaults.standard.setValue(urlString, forKey: "url")
            })
        })
    }

    @available(iOS 2.0, *)
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController){
        picker.dismiss(animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func showMess(title: String, message: String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        let ok = UIAlertAction(title: "OK", style: .default, handler: { (UIAlertAction) in
            if title != "Error"{
                self.dismiss(animated: true, completion: nil)
            }
        })
        alert.addAction(ok)
        self.present(alert, animated: true, completion: nil)
    
    }
}
