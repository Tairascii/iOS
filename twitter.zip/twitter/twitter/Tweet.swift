//
//  Tweet.swift
//  twitter
//
//  Created by Tair Sairanbekov on 14.04.2021.
//

import Foundation
import FirebaseDatabase
struct Tweet {
    var id: String?
    var tweet: String?
    var date: String?
    var nick: String?
    var hashtag: String?
    var dict: [String: String]{
        return [
            "id": id!,
            "tweet": tweet!,
            "date": date!,
            "nick": nick!,
            "hashtag": hashtag!
        ]
    }
    init(_ id: String, _ tweet: String, _ date: String, _ nick: String, _ hashtag: String){
        self.id = id
        self.tweet = tweet
        self.date = date
        self.nick = nick
        self.hashtag = hashtag
    }
    init(snapshot: DataSnapshot){
        if let value = snapshot.value as? [String: String]{
            id = value["id"]
            tweet = value["tweet"]
            date = value["date"]
            nick = value["nick"]
            hashtag = value["hashtag"]
        }
    }
    
}
